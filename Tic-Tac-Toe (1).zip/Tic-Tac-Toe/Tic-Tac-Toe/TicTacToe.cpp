#include <iostream>
#include "StartingPoint.h"
#include "Menu.h"
#include "Game.h"
#include "Info.h"
#include "Rules.h"
using namespace std;

int main()
{
    //change console color
    system("color B"); 

    //print out starting point
    startingPoint();
}